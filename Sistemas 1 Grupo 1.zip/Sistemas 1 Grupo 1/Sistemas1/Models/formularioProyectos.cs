﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sistemas1.Models
{
    public class formularioProyectos
    {
        [Key]
        public int Id { get; set; }

        public string Nombre { get; set; }

        [DataType(DataType.MultilineText)]
        public string Descripcion { get; set; }

        [DisplayName("Usuario")]
        public string IdUsuario { get; set; }
    }
}