﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Sistemas1.Models
{
    public class registrados
    {
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string CI { get; set; }

        [DisplayName("Tipo de Usuario")]
        public string TipoUsuario { get; set; }
    }
}