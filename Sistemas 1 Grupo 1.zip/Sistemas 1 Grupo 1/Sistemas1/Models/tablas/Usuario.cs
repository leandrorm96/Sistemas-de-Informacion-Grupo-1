﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sistemas1.Models.tablas
{
    [Table("usuario")]
    public class Usuario
    {
        [Key]
        public string UserId { get; set; }

        public string Contrasena { get; set; }


        [ForeignKey("Persona"),Column(Order =0)]
        public string CIPersona { get; set; }

        [ForeignKey("Tipo"),Column(Order =1)]
        public int IdTipoUsuario { get; set; }

        [ForeignKey("Pago"),Column(Order =2)]
        public int? IdPago { get; set; }

        public virtual Persona Persona { get; set; }

        public virtual TipoUsuario Tipo { get; set; }

        public virtual Pago Pago { get; set; }
    }
}