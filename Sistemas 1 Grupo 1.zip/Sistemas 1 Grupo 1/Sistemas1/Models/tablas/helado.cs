﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sistemas1.Models.tablas
{
    [Table("helado")]
    public class helado
    {
        [Key]
        public int idhelado{ get; set; }

        public string nombrehelado { get; set; }

        public string saborhelado { get; set; }
    }
}