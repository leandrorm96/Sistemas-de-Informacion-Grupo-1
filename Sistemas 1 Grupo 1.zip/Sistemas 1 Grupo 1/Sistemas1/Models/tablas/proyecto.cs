﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sistemas1.Models.tablas
{
    [Table("proyecto")]
    public class proyecto
    {
        [Key]
        public int Id { get; set; }

        public string Nombre { get; set; }

        public string Descripcion { get; set; }

        [ForeignKey("Usuario"),Column(Order =0)]
        public string IdUsuario { get; set; }

        [ForeignKey("Rubro"),Column(Order =1)]
        public int? IdRubro { get; set; }

        public virtual Usuario Usuario { get; set; }

        public virtual Rubro Rubro { get; set; }
    }
}