﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sistemas1.Models.tablas
{
    [Table("cv")]
    public class CV
    {
        [Key]
        public int Id { get; set; }

        public string FormacionAcademica { get; set; }

        public string PracticasProfesionales { get; set; }

        public string ExperienciaProfesional { get; set; }

        public string Idiomas { get; set; }
    }
}