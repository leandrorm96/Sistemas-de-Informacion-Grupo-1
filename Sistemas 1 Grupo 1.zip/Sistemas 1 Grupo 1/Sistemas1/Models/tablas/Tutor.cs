﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sistemas1.Models.tablas
{
    [Table("tutor")]
    public class Tutor
    {
        [Key]
        public string TutorLogin { get; set; }

        public string Contrasena { get; set; }

        public string Correo { get; set; }

        [ForeignKey("CV"),Column(Order =0)]
        public int? CVId { get; set; }

        [ForeignKey("Persona"),Column(Order =1)]
        public string CIPersona { get; set; }

        public virtual CV CV { get; set; }

        public virtual Persona Persona { get; set; }
    }
}