﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sistemas1.Models.tablas
{
    [Table("pago")]
    public class Pago
    {
        [Key]
        public int Id { get; set; }

        public string NroTarjeta { get; set; }

        public string CVC { get; set; }

        public DateTime FechaExp {get;set;}
    }
}