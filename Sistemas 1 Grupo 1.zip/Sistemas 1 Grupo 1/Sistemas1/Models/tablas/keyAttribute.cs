﻿using System;

namespace Sistemas1.Models.tablas
{
    internal class keyAttribute : Attribute
    {
    }
}