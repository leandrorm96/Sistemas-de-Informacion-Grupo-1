﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sistemas1.Models
{
    [Table("usuarios")]
    public class usuario
    {
        public string Nombre { get; set; }

        public string Apellido { get; set; }

        [Key]
        public string login { get; set; }

        public string correo { get; set; }

        public string contrasenha { get; set; }
    }
}