﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sistemas1.Models
{

    public class FormularioRegistro
    {
        public string Nombres { get; set; }

        [DisplayName("Apellido Paterno")]
        public string Apellido_P { get; set; }

        [DisplayName("Apellido Materno")]
        public string Apellido_M { get; set; }

        public string CI { get; set; }

        public string Usuario { get; set; }

        public string Password { get; set; }

        [DisplayName("Tipo de Usuario")]
        public string TipoUsu { get; set; }
    }
}