﻿using Sistemas1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sistemas1.Controllers.aplicaciones
{
    public class GestionUsuarios
    {
        public List<registrados> obtenerusuarios()
        {
            List<registrados> listado = new List<registrados>();
            try
            {
                using (var db = new basedatos())
                {
                    foreach(var elem in db.Usuarios.Include("Persona").Include("Tipo"))
                    {
                        var nuevo = new registrados();
                        nuevo.Nombres = elem.Persona.Nombres;
                        nuevo.Apellidos = elem.Persona.Apellido_P + " " + elem.Persona.Apellido_M;
                        nuevo.CI = elem.Persona.CI;
                        nuevo.TipoUsuario = elem.Tipo.Nombre;
                        listado.Add(nuevo);
                    }
                    foreach(var elem in db.Tutores.Include("Persona"))
                    {
                        listado.Add(new registrados()
                        {
                            Nombres=elem.Persona.Nombres,
                            Apellidos = elem.Persona.Apellido_P + " " + elem.Persona.Apellido_M,
                            CI = elem.Persona.CI,
                            TipoUsuario = "Tutor"
                        });
                    }
                }
            }
            catch(Exception e)
            {
                return listado;
            }
            return listado;
        }

        public FormularioRegistro obteneruno(string CI)
        {
            FormularioRegistro fr = new FormularioRegistro();

            try
            {
                using(var db=new basedatos())
                {
                    var item = db.Usuarios.FirstOrDefault(x => x.Persona.CI == CI);
                    if (item != null)
                    {
                        fr.CI = CI;
                        fr.Nombres = item.Persona.Nombres;
                        fr.Apellido_P = item.Persona.Apellido_P;
                        fr.Apellido_M = item.Persona.Apellido_M;
                        fr.Password = item.Contrasena;
                        fr.Usuario = item.UserId;
                        fr.TipoUsu = item.Tipo.Nombre;
                    }
                    else
                    {
                        var item2 = db.Tutores.FirstOrDefault(x => x.Persona.CI == CI);
                        if (item2 != null)
                        {
                            fr.CI = CI;
                            fr.Nombres = item2.Persona.Nombres;
                            fr.Apellido_P = item2.Persona.Apellido_P;
                            fr.Apellido_M = item2.Persona.Apellido_M;
                            fr.Password = item2.Contrasena;
                            fr.Usuario = item2.TutorLogin;
                            fr.TipoUsu = "Tutor";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            
            return fr;
        }

        public void Eliminaruno(string CI)
        {
            try
            {
                using(var db=new basedatos())
                {
                    var item = db.Usuarios.FirstOrDefault(x => x.Persona.CI == CI);
                    if (item != null)
                    {
                        var persona = db.Personas.FirstOrDefault(x => x.CI == CI);
                        db.Usuarios.Remove(item);
                        db.Personas.Remove(persona);
                        
                    }
                    else
                    {
                        var item2 = db.Tutores.FirstOrDefault(x => x.Persona.CI == CI);
                        if (item2 != null)
                        {
                            var persona = db.Personas.FirstOrDefault(x => x.CI == CI);
                            db.Tutores.Remove(item2);
                            db.Personas.Remove(persona);
                        }
                    }

                    db.SaveChanges();
                }
            }
            catch (Exception)
            {

            }
        }
    }
}