﻿using Sistemas1.Controllers.aplicaciones;
using Sistemas1.Models;
using Sistemas1.Models.tablas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sistemas1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            if (User.IsInRole("ADMIN"))
            {
                GestionUsuarios gs = new GestionUsuarios();
                List<registrados> lista = new List<registrados>();
                lista = gs.obtenerusuarios();
                return View(lista);
            }
            else
            {
                if (User.IsInRole("Tutor"))
                {
                    return RedirectToAction("Tutores","Home");
                }
                else
                {
                    return RedirectToAction("Usuarios","Home");
                }
            }
            
        }

        public ActionResult Tutores()
        {
            List<formularioProyectos> listado = new List<formularioProyectos>();
            try
            {
                using(var db=new basedatos())
                {
                    listado = db.Proyectos.Select(x => new formularioProyectos()
                    {
                        Id = x.Id,
                        Nombre=x.Nombre,
                        Descripcion=x.Descripcion,
                        IdUsuario=x.IdUsuario
                    }).ToList();
                }
            }
            catch (Exception)
            {

            }
            return View(listado);
        }

        public ActionResult Usuarios()
        {
            List<formularioProyectos> listado = new List<formularioProyectos>();
            try
            {
                using (var db = new basedatos())
                {
                    listado = db.Proyectos.Select(x => new formularioProyectos()
                    {
                        Id = x.Id,
                        Nombre = x.Nombre,
                        Descripcion = x.Descripcion,
                        IdUsuario = x.IdUsuario
                    }).Where(x => x.IdUsuario == User.Identity.Name).ToList();
                }
            }
            catch (Exception)
            {

            }
            return View(listado);
        }

        public ActionResult Nuevo()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Nuevo(FormularioRegistro datosregistro)
        {
            loginmodel modelo = new loginmodel();
            try
            {
                using (var db = new basedatos())
                {
                    if (datosregistro.TipoUsu != "3")
                    {
                        Usuario nuevo = new Usuario();
                        Persona nueva = new Persona();
                        nueva.CI = datosregistro.CI;
                        nueva.Nombres = datosregistro.Nombres;
                        nueva.Apellido_M = datosregistro.Apellido_M;
                        nueva.Apellido_P = datosregistro.Apellido_P;
                        db.Personas.Add(nueva);
                        nuevo.CIPersona = datosregistro.CI;
                        nuevo.UserId = datosregistro.Usuario;
                        nuevo.Contrasena = datosregistro.Password;
                        nuevo.IdTipoUsuario = Int32.Parse(datosregistro.TipoUsu);
                        db.Usuarios.Add(nuevo);
                        db.SaveChanges();
                    }
                    else
                    {
                        Persona nueva = new Persona();
                        nueva.CI = datosregistro.CI;
                        nueva.Nombres = datosregistro.Nombres;
                        nueva.Apellido_M = datosregistro.Apellido_M;
                        nueva.Apellido_P = datosregistro.Apellido_P;
                        db.Personas.Add(nueva);
                        Tutor nuevo = new Tutor();
                        nuevo.CIPersona = datosregistro.CI;
                        nuevo.TutorLogin = datosregistro.Usuario;
                        nuevo.Contrasena = datosregistro.Password;
                        nuevo.CVId = null;
                        //falta correo y CV...
                        db.Tutores.Add(nuevo);
                        db.SaveChanges();
                    }
                }
            }
            catch (Exception)
            {
                return View();
            }

            return RedirectToAction("Index", "Home");
        }

        public ActionResult Edit(string CI)
        {
            GestionUsuarios g = new GestionUsuarios();
            FormularioRegistro fr = new FormularioRegistro();
            try
            {
                fr = g.obteneruno(CI);
                return View(fr);
            }
            catch(Exception e)
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpPost]
        public ActionResult Edit(FormularioRegistro datosregistro)
        {
            try
            {
                using (var db = new basedatos())
                {
                    if (datosregistro.TipoUsu != "3")
                    {
                        Usuario nuevo = new Usuario();
                        Persona nueva = new Persona();
                        nueva.CI = datosregistro.CI;
                        nueva.Nombres = datosregistro.Nombres;
                        nueva.Apellido_M = datosregistro.Apellido_M;
                        nueva.Apellido_P = datosregistro.Apellido_P;
                        db.Personas.Attach(nueva);
                        db.Entry(nueva).State = System.Data.Entity.EntityState.Modified;
                        nuevo.CIPersona = datosregistro.CI;
                        nuevo.UserId = datosregistro.Usuario;
                        nuevo.Contrasena = datosregistro.Password;
                        nuevo.IdTipoUsuario = Int32.Parse(datosregistro.TipoUsu);
                        db.Usuarios.Attach(nuevo);
                        db.Entry(nuevo).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                    }
                    else
                    {
                        Persona nueva = new Persona();
                        nueva.CI = datosregistro.CI;
                        nueva.Nombres = datosregistro.Nombres;
                        nueva.Apellido_M = datosregistro.Apellido_M;
                        nueva.Apellido_P = datosregistro.Apellido_P;
                        db.Personas.Attach(nueva);
                        db.Entry(nueva).State = System.Data.Entity.EntityState.Modified;
                        Tutor nuevo = new Tutor();
                        nuevo.CIPersona = datosregistro.CI;
                        nuevo.TutorLogin = datosregistro.Usuario;
                        nuevo.Contrasena = datosregistro.Password;
                        nuevo.CVId = null;
                        //falta correo y CV...
                        db.Tutores.Attach(nuevo);
                        db.Entry(nuevo).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("Edit", "Home",new { CI=datosregistro.CI});
            }

            return RedirectToAction("Index", "Home");
        }

        public ActionResult Delete(string CI)
        {
            try
            {
                using(var db=new basedatos())
                {
                    GestionUsuarios gs = new GestionUsuarios();
                    gs.Eliminaruno(CI);
                }
            }
            catch (Exception)
            {

            }

            return RedirectToAction("Index", "Home");
        }

        public ActionResult DetailProy(int Id)
        {
            formularioProyectos proy = new formularioProyectos();
            try
            {
                using(var db=new basedatos())
                {
                    var item = db.Proyectos.FirstOrDefault(x => x.Id == Id);
                    if (item != null)
                    {
                        proy.Nombre = item.Nombre;
                        proy.Descripcion = item.Descripcion;
                        proy.IdUsuario = item.IdUsuario;
                        proy.Id = item.Id;
                    }
                }
            }
            catch (Exception)
            {

            }
            return View(proy);
        }

        public ActionResult NuevoProy()
        {
            formularioProyectos registronuevo = new formularioProyectos();
            return View(registronuevo);
        }

        [HttpPost]
        public ActionResult NuevoProy(formularioProyectos registronuevo)
        {
            try
            {
                proyecto nuevo = new proyecto();
                nuevo.IdRubro = 1;
                nuevo.Nombre = registronuevo.Nombre;
                nuevo.IdUsuario = User.Identity.Name;
                nuevo.Descripcion = registronuevo.Descripcion;
                using(var db=new basedatos())
                {
                    db.Proyectos.Add(nuevo);
                    db.SaveChanges();
                }
            }
            catch (Exception)
            {

            }
            return RedirectToAction("Index", "Home");
        }

        public ActionResult EliminarProy(int Id)
        {
            try
            {
                using(var db=new basedatos())
                {
                    var item = db.Proyectos.FirstOrDefault(x => x.Id == Id);
                    if (item != null)
                    {
                        db.Proyectos.Remove(item);
                        db.SaveChanges();
                    }
                }
            }
            catch (Exception)
            {

            }
            return RedirectToAction("Index", "Home");
        }
    }

}