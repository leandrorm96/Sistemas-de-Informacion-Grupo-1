﻿using Sistemas1.Models.tablas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sistemas1.Controllers
{
    public class PruebaController : Controller
    {
        // GET: Prueba
        public ActionResult Index()
        {
            var listado = new List<Muestra>();
            using(var db=new basedatos())
            {
                listado = db.Muestras.ToList();
            }
            return View(listado);
        }
    }
}