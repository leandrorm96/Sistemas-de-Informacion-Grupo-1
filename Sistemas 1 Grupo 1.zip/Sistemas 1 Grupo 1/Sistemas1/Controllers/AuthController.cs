﻿using Sistemas1.Models;
using Sistemas1.Models.tablas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;

namespace Sistemas1.Controllers
{
    [AllowAnonymous]
    public class AuthController : Controller
    {
        // GET: Auth
        public ActionResult login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult login(loginmodel datos)
        {

            //Checks whether the input is the same as those literals. Note: Never ever do this! This is just to demo the validation while we're not yet doing any database interaction
            using(var db=new basedatos())
            {
                var item = db.Usuarios.FirstOrDefault(x => x.UserId == datos.Usuario && x.Contrasena == datos.contrasena);
                if (item!=null)
                {
                    var identity = new ClaimsIdentity(new[] {
                        new Claim(ClaimTypes.Name, item.UserId),
                        new Claim(ClaimTypes.Email, "juan@eladmin.com"),
                        new Claim(ClaimTypes.Country, "Bolivia"),
                        new Claim(ClaimTypes.Role,item.Tipo.Nombre)
    }, "ApplicationCookie");
                    
                    var ctx = Request.GetOwinContext();
                    var authManager = ctx.Authentication;
                    authManager.SignIn(identity);

                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    //login tutores
                    var item2= db.Tutores.FirstOrDefault(x => x.TutorLogin == datos.Usuario && x.Contrasena == datos.contrasena);
                    if (item2 != null)
                    {
                        var identity = new ClaimsIdentity(new[] {
                        new Claim(ClaimTypes.Name, item2.Persona.Nombres),
                        new Claim(ClaimTypes.Email, "juan@eladmin.com"),
                        new Claim(ClaimTypes.Country, "Bolivia"),
                        new Claim(ClaimTypes.Role,"Tutor")
    }, "ApplicationCookie");

                        var ctx = Request.GetOwinContext();
                        var authManager = ctx.Authentication;
                        authManager.SignIn(identity);

                        return RedirectToAction("Index", "Home");
                    }
                }
            }
            ModelState.AddModelError("", "CREDENCIALES INVALIDAS");
    return View(datos); //Should always be declared on the end of an action method
    }
        public ActionResult Logout()
        {
            var ctx = Request.GetOwinContext();
            var authManager = ctx.Authentication;

            authManager.SignOut("ApplicationCookie");
            return RedirectToAction("Login", "Auth");
        }

        public ActionResult Registrarse()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Registrarse(FormularioRegistro datosregistro)
        {
            loginmodel modelo = new loginmodel();
            try
            {
                using (var db = new basedatos())
                {
                    if (datosregistro.TipoUsu != "3")
                    {
                        Usuario nuevo = new Usuario();
                        Persona nueva = new Persona();
                        nueva.CI = datosregistro.CI;
                        nueva.Nombres = datosregistro.Nombres;
                        nueva.Apellido_M = datosregistro.Apellido_M;
                        nueva.Apellido_P = datosregistro.Apellido_P;
                        db.Personas.Add(nueva);
                        nuevo.CIPersona = datosregistro.CI;
                        nuevo.UserId = datosregistro.Usuario;
                        nuevo.Contrasena = datosregistro.Password;
                        nuevo.IdTipoUsuario = Int32.Parse(datosregistro.TipoUsu);
                        db.Usuarios.Add(nuevo);
                        db.SaveChanges();
                    }
                    else
                    {
                        Persona nueva = new Persona();
                        nueva.CI = datosregistro.CI;
                        nueva.Nombres = datosregistro.Nombres;
                        nueva.Apellido_M = datosregistro.Apellido_M;
                        nueva.Apellido_P = datosregistro.Apellido_P;
                        db.Personas.Add(nueva);
                        Tutor nuevo = new Tutor();
                        nuevo.CIPersona = datosregistro.CI;
                        nuevo.TutorLogin = datosregistro.Usuario;
                        nuevo.Contrasena = datosregistro.Password;
                        nuevo.CVId = null;
                        //falta correo y CV...
                        db.Tutores.Add(nuevo);
                        db.SaveChanges();
                    }
                }
            }
            catch(Exception)
            {
                return View();
            }
            modelo.Usuario = datosregistro.Usuario;
            modelo.contrasena = datosregistro.Password;
            return login(modelo);
        }
    }
}