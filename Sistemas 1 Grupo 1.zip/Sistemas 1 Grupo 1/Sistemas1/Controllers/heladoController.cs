﻿using Sistemas1.Models.tablas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sistemas1.Controllers
{
    public class heladoController : Controller
    {
        // GET: helado
        public ActionResult Index()
        {
            var listado = new List<helado>();
            using (var db = new basedatos())
            {
                listado = db.helados.ToList();
            }
            return View(listado);
        }
    }
}