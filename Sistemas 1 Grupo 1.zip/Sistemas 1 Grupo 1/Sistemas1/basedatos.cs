﻿using Sistemas1.Models;
using Sistemas1.Models.tablas;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Sistemas1
{
    public class basedatos:DbContext
    {
        public basedatos()
            :base("BDMYSQL")
        {

        }

        public DbSet<CV> CVs { get; set; }

        public DbSet<Pago> Pagos { get; set; }

        public DbSet<Persona> Personas { get; set; }

        public DbSet<TipoUsuario> TipoUsuarios { get; set; }

        public DbSet<Tutor> Tutores { get; set; }

        public DbSet<Usuario> Usuarios { get; set; }

        public DbSet<Muestra> Muestras { get; set; }

        public DbSet<proyecto> Proyectos { get; set; }

        public DbSet<Rubro> Rubros { get; set; }

        public DbSet<helado> helados { get; set; }
    }
}